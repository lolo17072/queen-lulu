const messages = [
  "تعرفي شو اللي بميزك؟ إنك دايمًا قادرة تحولي يومي العادي ليوم أسطوري بس من صوتك، من ضحكتك، من وجودك... بحبك. 💗",
  "كل لحظة بتمر وأنا بحبك أكتر، وكل يوم بحس حالي محظوظ إنك إنتي شريكتي وملكتي ودنيتي. 💌",
  "شو ما كتبت، وشو ما وصفت، رح تظلي أرقى من كل الكلام، وأجمل من كل الحروف. 👑",
  "ملكتي لولو، حضورك بحياتي خلاني أؤمن إن الدنيا ممكن تكون وردية، وإن الحب مش بس كلمة، هو إنتي بكل تفاصيلك. 🌷"
];
function $(id){ return document.getElementById(id); }
function selectRole(role){
  $("role-selection").classList.add("hidden");
  if(role==="queen") $("queen-interface").classList.remove("hidden");
  else $("serse7-interface").classList.remove("hidden");
}
function showRandomMessage(){
  const msg = messages[Math.floor(Math.random()*messages.length)];
  const box = $("messageBox");
  box.textContent = msg;
  box.classList.remove("hidden");
  saveData();
}
function saveQueenVent(){
  saveData();
  alert("تم حفظ فضفضتك!");
}
function addDream(){
  const val = $("dream-input").value.trim();
  if(val){
    const li = document.createElement("li");
    li.textContent = val;
    $("dream-list").appendChild(li);
    $("dream-input").value="";
    saveData();
  }
}
function addWish(){
  const val = $("wish-input").value.trim();
  if(val){
    const li = document.createElement("li");
    li.textContent = val;
    $("wish-list").appendChild(li);
    $("wish-input").value="";
    saveData();
  }
}
function newChallenge(){
  const desc = prompt("اكتب التحدي:");
  if(desc){
    const li = document.createElement("li");
    li.textContent = desc + " ";
    const btnOk = document.createElement("button");
    btnOk.textContent="أنجزت";
    btnOk.onclick=()=>{ updatePiggy(1); };
    const btnFail = document.createElement("button");
    btnFail.textContent="لم أنجز";
    btnFail.onclick=()=>{ updatePiggy(-1); };
    li.appendChild(btnOk);
    li.appendChild(btnFail);
    $("challenge-list").appendChild(li);
    saveData();
  }
}
function updatePiggy(val){
  const cnt = parseInt(localStorage.getItem("piggy")||"0")+val;
  localStorage.setItem("piggy",cnt);
  $("piggy-count").textContent=cnt;
}
function saveData(){
  const data = {
    vent: $("queen-vent").value,
    dreams: Array.from($("dream-list").children).map(li=>li.textContent),
    wishes: Array.from($("wish-list").children).map(li=>li.textContent),
    piggy: $("piggy-count").textContent
  };
  localStorage.setItem("luluData", JSON.stringify(data));
}
function loadData(){
  const data = JSON.parse(localStorage.getItem("luluData")||"{}");
  if(data.vent) $("queen-vent").value=data.vent;
  (data.dreams||[]).forEach(d=>{
    const li = document.createElement("li"); li.textContent=d; $("dream-list").appendChild(li);
  });
  (data.wishes||[]).forEach(w=>{
    const li = document.createElement("li"); li.textContent=w; $("wish-list").appendChild(li);
  });
  if(data.piggy) $("piggy-count").textContent=data.piggy;
}
window.onload = loadData;